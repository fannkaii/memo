﻿namespace VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Runtime.Serialization;
    using System.Threading;

    [Serializable, DebuggerStepThrough, GeneratedCode("System.Runtime.Serialization", "4.0.0.0"), DataContract(Name="ExpressTask", Namespace="http://schemas.datacontract.org/2004/07/VWFSCN.IT.DeMortagage.MRPrinter.Service")]
    public class ExpressTask : IExtensibleDataObject, INotifyPropertyChanged
    {
        [NonSerialized]
        private ExtensionDataObject extensionDataField;
        [OptionalField]
        private string ContactNoField;
        [OptionalField]
        private string DealerCodeField;
        [OptionalField]
        private string DealerNameField;
        [OptionalField]
        private string DeliveryAddressField;
        [OptionalField]
        private string RecipientField;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                propertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [Browsable(false)]
        public ExtensionDataObject ExtensionData
        {
            get => 
                this.extensionDataField;
            set => 
                (this.extensionDataField = value);
        }

        [DataMember]
        public string ContactNo
        {
            get => 
                this.ContactNoField;
            set
            {
                if (!object.ReferenceEquals(this.ContactNoField, value))
                {
                    this.ContactNoField = value;
                    this.RaisePropertyChanged("ContactNo");
                }
            }
        }

        [DataMember]
        public string DealerCode
        {
            get => 
                this.DealerCodeField;
            set
            {
                if (!object.ReferenceEquals(this.DealerCodeField, value))
                {
                    this.DealerCodeField = value;
                    this.RaisePropertyChanged("DealerCode");
                }
            }
        }

        [DataMember]
        public string DealerName
        {
            get => 
                this.DealerNameField;
            set
            {
                if (!object.ReferenceEquals(this.DealerNameField, value))
                {
                    this.DealerNameField = value;
                    this.RaisePropertyChanged("DealerName");
                }
            }
        }

        [DataMember]
        public string DeliveryAddress
        {
            get => 
                this.DeliveryAddressField;
            set
            {
                if (!object.ReferenceEquals(this.DeliveryAddressField, value))
                {
                    this.DeliveryAddressField = value;
                    this.RaisePropertyChanged("DeliveryAddress");
                }
            }
        }

        [DataMember]
        public string Recipient
        {
            get => 
                this.RecipientField;
            set
            {
                if (!object.ReferenceEquals(this.RecipientField, value))
                {
                    this.RecipientField = value;
                    this.RaisePropertyChanged("Recipient");
                }
            }
        }
    }
}

