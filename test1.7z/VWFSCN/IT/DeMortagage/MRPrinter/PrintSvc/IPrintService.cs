﻿namespace VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc
{
    using System;
    using System.CodeDom.Compiler;
    using System.Runtime.InteropServices;
    using System.ServiceModel;

    [ServiceContract(ConfigurationName="PrintSvc.IPrintService"), GeneratedCode("System.ServiceModel", "4.0.0.0")]
    public interface IPrintService
    {
        [OperationContract(Action="http://tempuri.org/IPrintService/DocMax", ReplyAction="http://tempuri.org/IPrintService/DocMaxResponse")]
        int DocMax(string userName);
        [OperationContract(Action="http://tempuri.org/IPrintService/DocPopup", ReplyAction="http://tempuri.org/IPrintService/DocPopupResponse")]
        DocTask[] DocPopup(string userName);
        [OperationContract(Action="http://tempuri.org/IPrintService/DocPopupLeader", ReplyAction="http://tempuri.org/IPrintService/DocPopupLeaderResponse")]
        DocTask[] DocPopupLeader(out LeaderPage lpData, string userName);
        [OperationContract(Action="http://tempuri.org/IPrintService/ExpressMax", ReplyAction="http://tempuri.org/IPrintService/ExpressMaxResponse")]
        int ExpressMax(string userName);
        [OperationContract(Action="http://tempuri.org/IPrintService/ExpressPopup", ReplyAction="http://tempuri.org/IPrintService/ExpressPopupResponse")]
        ExpressTask ExpressPopup(string userName);
        [OperationContract(Action="http://tempuri.org/IPrintService/PrintErrorLog", ReplyAction="http://tempuri.org/IPrintService/PrintErrorLogResponse")]
        void PrintErrorLog(DocTask task, string error);
    }
}

