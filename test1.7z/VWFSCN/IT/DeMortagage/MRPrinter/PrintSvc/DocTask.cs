﻿namespace VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Runtime.Serialization;
    using System.Threading;

    [Serializable, DataContract(Name="DocTask", Namespace="http://schemas.datacontract.org/2004/07/VWFSCN.IT.DeMortagage.MRPrinter.Service"), DebuggerStepThrough, GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
    public class DocTask : IExtensibleDataObject, INotifyPropertyChanged
    {
        [NonSerialized]
        private ExtensionDataObject extensionDataField;
        [OptionalField]
        private int ApplicationIdField;
        [OptionalField]
        private bool BothSideField;
        [OptionalField]
        private int CopiesField;
        [OptionalField]
        private int DetailIdField;
        [OptionalField]
        private int DocumentIdField;
        [OptionalField]
        private string FilePathField;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                propertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [Browsable(false)]
        public ExtensionDataObject ExtensionData
        {
            get => 
                this.extensionDataField;
            set => 
                (this.extensionDataField = value);
        }

        [DataMember]
        public int ApplicationId
        {
            get => 
                this.ApplicationIdField;
            set
            {
                if (!this.ApplicationIdField.Equals(value))
                {
                    this.ApplicationIdField = value;
                    this.RaisePropertyChanged("ApplicationId");
                }
            }
        }

        [DataMember]
        public bool BothSide
        {
            get => 
                this.BothSideField;
            set
            {
                if (!this.BothSideField.Equals(value))
                {
                    this.BothSideField = value;
                    this.RaisePropertyChanged("BothSide");
                }
            }
        }

        [DataMember]
        public int Copies
        {
            get => 
                this.CopiesField;
            set
            {
                if (!this.CopiesField.Equals(value))
                {
                    this.CopiesField = value;
                    this.RaisePropertyChanged("Copies");
                }
            }
        }

        [DataMember]
        public int DetailId
        {
            get => 
                this.DetailIdField;
            set
            {
                if (!this.DetailIdField.Equals(value))
                {
                    this.DetailIdField = value;
                    this.RaisePropertyChanged("DetailId");
                }
            }
        }

        [DataMember]
        public int DocumentId
        {
            get => 
                this.DocumentIdField;
            set
            {
                if (!this.DocumentIdField.Equals(value))
                {
                    this.DocumentIdField = value;
                    this.RaisePropertyChanged("DocumentId");
                }
            }
        }

        [DataMember]
        public string FilePath
        {
            get => 
                this.FilePathField;
            set
            {
                if (!object.ReferenceEquals(this.FilePathField, value))
                {
                    this.FilePathField = value;
                    this.RaisePropertyChanged("FilePath");
                }
            }
        }
    }
}

