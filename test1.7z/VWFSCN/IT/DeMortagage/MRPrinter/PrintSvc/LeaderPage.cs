﻿namespace VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Runtime.Serialization;
    using System.Threading;

    [Serializable, GeneratedCode("System.Runtime.Serialization", "4.0.0.0"), DataContract(Name="LeaderPage", Namespace="http://schemas.datacontract.org/2004/07/VWFSCN.IT.DeMortagage.MRPrinter.Service"), DebuggerStepThrough]
    public class LeaderPage : IExtensibleDataObject, INotifyPropertyChanged
    {
        [NonSerialized]
        private ExtensionDataObject extensionDataField;
        [OptionalField]
        private int AllPagesField;
        [OptionalField]
        private string CityField;
        [OptionalField]
        private string DealerField;
        [OptionalField]
        private string DealerCodeField;
        [OptionalField]
        private string DocumentsListField;
        [OptionalField]
        private string SalesAreaField;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                propertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [Browsable(false)]
        public ExtensionDataObject ExtensionData
        {
            get => 
                this.extensionDataField;
            set => 
                (this.extensionDataField = value);
        }

        [DataMember]
        public int AllPages
        {
            get => 
                this.AllPagesField;
            set
            {
                if (!this.AllPagesField.Equals(value))
                {
                    this.AllPagesField = value;
                    this.RaisePropertyChanged("AllPages");
                }
            }
        }

        [DataMember]
        public string City
        {
            get => 
                this.CityField;
            set
            {
                if (!object.ReferenceEquals(this.CityField, value))
                {
                    this.CityField = value;
                    this.RaisePropertyChanged("City");
                }
            }
        }

        [DataMember]
        public string Dealer
        {
            get => 
                this.DealerField;
            set
            {
                if (!object.ReferenceEquals(this.DealerField, value))
                {
                    this.DealerField = value;
                    this.RaisePropertyChanged("Dealer");
                }
            }
        }

        [DataMember]
        public string DealerCode
        {
            get => 
                this.DealerCodeField;
            set
            {
                if (!object.ReferenceEquals(this.DealerCodeField, value))
                {
                    this.DealerCodeField = value;
                    this.RaisePropertyChanged("DealerCode");
                }
            }
        }

        [DataMember]
        public string DocumentsList
        {
            get => 
                this.DocumentsListField;
            set
            {
                if (!object.ReferenceEquals(this.DocumentsListField, value))
                {
                    this.DocumentsListField = value;
                    this.RaisePropertyChanged("DocumentsList");
                }
            }
        }

        [DataMember]
        public string SalesArea
        {
            get => 
                this.SalesAreaField;
            set
            {
                if (!object.ReferenceEquals(this.SalesAreaField, value))
                {
                    this.SalesAreaField = value;
                    this.RaisePropertyChanged("SalesArea");
                }
            }
        }
    }
}

