﻿namespace VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc
{
    using System;
    using System.CodeDom.Compiler;
    using System.Diagnostics;
    using System.Runtime.InteropServices;
    using System.ServiceModel;
    using System.ServiceModel.Channels;

    [GeneratedCode("System.ServiceModel", "4.0.0.0"), DebuggerStepThrough]
    public class PrintServiceClient : ClientBase<IPrintService>, IPrintService
    {
        public PrintServiceClient()
        {
        }

        public PrintServiceClient(string endpointConfigurationName) : base(endpointConfigurationName)
        {
        }

        public PrintServiceClient(Binding binding, EndpointAddress remoteAddress) : base(binding, remoteAddress)
        {
        }

        public PrintServiceClient(string endpointConfigurationName, EndpointAddress remoteAddress) : base(endpointConfigurationName, remoteAddress)
        {
        }

        public PrintServiceClient(string endpointConfigurationName, string remoteAddress) : base(endpointConfigurationName, remoteAddress)
        {
        }

        public int DocMax(string userName) => 
            base.Channel.DocMax(userName);

        public DocTask[] DocPopup(string userName) => 
            base.Channel.DocPopup(userName);

        public DocTask[] DocPopupLeader(out LeaderPage lpData, string userName) => 
            base.Channel.DocPopupLeader(out lpData, userName);

        public int ExpressMax(string userName) => 
            base.Channel.ExpressMax(userName);

        public ExpressTask ExpressPopup(string userName) => 
            base.Channel.ExpressPopup(userName);

        public void PrintErrorLog(DocTask task, string error)
        {
            base.Channel.PrintErrorLog(task, error);
        }
    }
}

