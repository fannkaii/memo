﻿namespace VWFSCN.IT.DeMortagage.MRPrinter
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Configuration;
    using System.Drawing;
    using System.Drawing.Printing;
    using System.Threading;
    using System.Windows.Forms;
    using VWFSCN.IT.Common;
    using VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc;

    public class frmExpressPrint : Form, IPrintStatus
    {
        private const string StrWaiting = "Waiting for print express...";
        private const string StrStoped = "Express printing Stopped...";
        private int _timeSpan = 60;
        private bool _isWorking = true;
        private Thread _threadExpress;
        private bool _exportIsWorking;
        private bool _haveNext;
        private string _dkx;
        private PrintServiceClient _client = new PrintServiceClient();
        private string _runas = string.Empty;
        private IContainer components = null;
        private ProgressBar progressBar1;
        private Label label1;
        private Button button1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;

        public frmExpressPrint()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ("stop".Equals(this.button1.Text.ToLower()))
            {
                this._isWorking = false;
                this._haveNext = false;
                this.button1.Text = "Start";
                this.button1.BackColor = SystemColors.Control;
                this.label1.BackColor = SystemColors.ControlDark;
                this.button1.ForeColor = Color.Black;
                this.Cursor = Cursors.WaitCursor;
                Thread.Sleep((int) (this._timeSpan * 0x3e8));
                this.Cursor = Cursors.Default;
                this.label1.Text = "Express printing Stopped...";
            }
            else
            {
                this._isWorking = true;
                this.button1.BackColor = SystemColors.ControlDark;
                this.label1.BackColor = SystemColors.Control;
                this.button1.ForeColor = Color.White;
                this.button1.Text = "Stop";
                this.label1.Text = "Waiting for print express...";
                this._threadExpress = new Thread(new ThreadStart(this.checkExpress));
                this._threadExpress.Start();
            }
            this.toolStripMenuItem1.Text = this.button1.Text;
        }

        private void checkExpress()
        {
            while (this._isWorking)
            {
                if (!this._exportIsWorking)
                {
                    try
                    {
                        this.ExpressBillTemplateExportingJob();
                    }
                    catch (Exception exception)
                    {
                        VwfscnApplication.Current.LogWriter.Error(exception);
                        this.showProcessInfo(exception.Message);
                    }
                    finally
                    {
                        this._exportIsWorking = false;
                    }
                }
                Thread.Sleep((int) (this._timeSpan * 0x3e8));
            }
        }

        public void CloseJob()
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void ExpressBillTemplateExportingJob()
        {
            this._exportIsWorking = true;
            this._haveNext = true;
            while (this._haveNext)
            {
                string defaultPrinter = ConfigurationManager.get_AppSettings().Get("ExpressPrinterName");
                if (!(!string.IsNullOrWhiteSpace(defaultPrinter) && MSDocPrinter.PrinterHelper.CheckPrinterValid(defaultPrinter)))
                {
                    this.showProcessInfo("Please set the special printer to print Express Bill in the config file.");
                    break;
                }
                int num = this._client.ExpressMax(this._dkx);
                this.showProgressBar(num);
                ExpressTask task = this._client.ExpressPopup(this._dkx);
                if (task == null)
                {
                    this._haveNext = false;
                    this.SetWaiting();
                }
                else
                {
                    Dictionary<string, string> tempValues = new Dictionary<string, string> {
                        { 
                            "%1^",
                            task.Recipient
                        },
                        { 
                            "%2^",
                            task.ContactNo
                        },
                        { 
                            "%3^",
                            task.DealerName
                        },
                        { 
                            "%4^",
                            task.DeliveryAddress
                        },
                        { 
                            "%5^",
                            task.DealerCode
                        }
                    };
                    if (string.IsNullOrEmpty(defaultPrinter))
                    {
                        defaultPrinter = MSDocPrinter.PrinterHelper.GetDefaultPrinter();
                    }
                    string filename = $"{AppDomain.CurrentDomain.SetupInformation.ApplicationBase}{"ExpressMailTemplate.docx"}";
                    PaperSize ps = new PaperSize("12MRExpress", 0x4b0, 0x4f6);
                    MSDocPrinter.PrinterHelper.PrintWord(filename, defaultPrinter, 1, tempValues, ps);
                    VwfscnApplication.Current.LogWriter.Info($"Print: {task.DealerName} done.");
                    this.showProcessInfo(task.DealerName);
                }
            }
            this.showProgressBar(0);
            this._exportIsWorking = false;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            this._isWorking = false;
            if (this._threadExpress.IsAlive)
            {
                this._threadExpress.Abort();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this._dkx = this.RunAsUser;
            string str = ConfigurationManager.get_AppSettings().Get("timeSpan");
            this._timeSpan = Convert.ToInt32(str);
            if (this._timeSpan == 0)
            {
                this._timeSpan = 60;
            }
            this._threadExpress = new Thread(new ThreadStart(this.checkExpress));
            this._threadExpress.Start();
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.progressBar1 = new ProgressBar();
            this.label1 = new Label();
            this.button1 = new Button();
            this.contextMenuStrip1 = new ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.progressBar1.Dock = DockStyle.Top;
            this.progressBar1.Location = new Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0x124, 10);
            this.progressBar1.Style = ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 5;
            this.progressBar1.Visible = false;
            this.label1.BackColor = SystemColors.Control;
            this.label1.Dock = DockStyle.Fill;
            this.label1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0, 10);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x124, 0x49);
            this.label1.TabIndex = 4;
            this.label1.TextAlign = ContentAlignment.MiddleCenter;
            this.button1.BackColor = SystemColors.ControlDark;
            this.button1.Dock = DockStyle.Bottom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = FlatStyle.Flat;
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.ForeColor = Color.White;
            this.button1.Location = new Point(0, 0x53);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x124, 0x1b);
            this.button1.TabIndex = 3;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.contextMenuStrip1.Items.AddRange(new ToolStripItem[] { this.toolStripMenuItem1 });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new Size(0x61, 0x1a);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x60, 0x16);
            this.toolStripMenuItem1.Text = "Stop";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x124, 110);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.progressBar1);
            base.Controls.Add(this.button1);
            base.FormBorderStyle = FormBorderStyle.None;
            base.Name = "frmExpressPrint";
            this.Text = "frmExpressPrint";
            base.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
            base.Load += new EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        public void ResetSize()
        {
            this.Refresh();
        }

        private void SetWaiting()
        {
            Action<string> method = delegate (string n) {
                if (this.label1 != null)
                {
                    try
                    {
                        this.label1.Text = n;
                    }
                    catch (Exception)
                    {
                    }
                }
            };
            this.label1.Invoke(method, new object[] { "Waiting for print express..." });
        }

        private void showProcessInfo(string msg)
        {
            Action<string> method = n => this.label1.Text = n;
            this.label1.Invoke(method, new object[] { msg });
        }

        private void showProgressBar(int value)
        {
            Action<int> method = delegate (int n) {
                if (n == 0)
                {
                    this.progressBar1.Visible = false;
                }
                else if (!this.progressBar1.Visible)
                {
                    this.progressBar1.Visible = true;
                    this.progressBar1.Maximum = n;
                    this.progressBar1.Minimum = 1;
                    this.progressBar1.Value = 1;
                    this.progressBar1.Step = 1;
                }
                else if (n > this.progressBar1.Maximum)
                {
                    this.progressBar1.Maximum = n;
                }
                else
                {
                    try
                    {
                        this.progressBar1.Value = this.progressBar1.Maximum - n;
                    }
                    catch (Exception)
                    {
                    }
                }
            };
            this.progressBar1.Invoke(method, new object[] { value });
        }

        public void Start()
        {
            this._isWorking = true;
            this.button1.BackColor = SystemColors.ControlDark;
            this.label1.BackColor = SystemColors.Control;
            this.button1.ForeColor = Color.White;
            this.button1.Text = "Stop";
            this.label1.Text = "Waiting for print express...";
            this._threadExpress = new Thread(new ThreadStart(this.checkExpress));
            this._threadExpress.Start();
            this.toolStripMenuItem1.Text = this.button1.Text;
        }

        public void Stop()
        {
            this._isWorking = false;
            this._haveNext = false;
            this.button1.Text = "Start";
            this.button1.BackColor = SystemColors.Control;
            this.label1.BackColor = SystemColors.ControlDark;
            this.button1.ForeColor = Color.Black;
            this.Cursor = Cursors.WaitCursor;
            Thread.Sleep((int) (this._timeSpan * 0x3e8));
            this.Cursor = Cursors.Default;
            this.toolStripMenuItem1.Text = this.button1.Text;
            this.label1.Text = "Express printing Stopped...";
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.button1_Click(sender, e);
        }

        public string RunAsUser
        {
            get => 
                this._runas;
            set => 
                (this._runas = value);
        }
    }
}

