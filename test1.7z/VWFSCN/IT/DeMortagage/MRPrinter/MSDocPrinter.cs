﻿namespace VWFSCN.IT.DeMortagage.MRPrinter
{
    using Microsoft.Office.Interop.Word;
    using Spire.Doc;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Printing;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Text;
    using System.Windows.Forms;
    using VWFSCN.IT.Common;

    public class MSDocPrinter
    {
        [StructLayout(LayoutKind.Sequential)]
        public class DOCINFOA
        {
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDocName;
            [MarshalAs(UnmanagedType.LPStr)]
            public string pOutputFile;
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDataType;
        }

        public enum ePrinterState
        {
            UnknownStatus = -1,
            Ready = 0,
            Paused = 1,
            Error = 2,
            PendingDeletion = 4,
            PaperJam = 8,
            NoPaper = 0x10,
            ManualFeedPaper = 0x20,
            PaperProblem = 0x40,
            OffLine = 0x80,
            Transmitting = 0x100,
            Busy = 0x200,
            Printing = 0x400,
            OutputBinFull = 0x800,
            NotAvailable = 0x1000,
            Processing = 0x4000,
            Initializing = 0x8000,
            WarmingUp = 0x10000,
            TonerLow = 0x20000,
            NoToner = 0x40000,
            PagePunt = 0x80000,
            UserIntervention = 0x100000,
            OutOfMemory = 0x200000,
            DoorIsOpen = 0x400000,
            Waiting = 0x20000000
        }

        public enum ePrintFileType
        {
            Invalid = -1,
            TextFile = 0,
            Word = 1,
            Excel = 2
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct PRINTER_INFO_2
        {
            public string pServerName;
            public string pPrinterName;
            public string pShareName;
            public string pPortName;
            public string pDriverName;
            public string pComment;
            public string pLocation;
            public IntPtr pDevMode;
            public string pSepFile;
            public string pPrintProcessor;
            public string pDatatype;
            public string pParameters;
            public IntPtr pSecurityDescriptor;
            public uint Attributes;
            public uint Priority;
            public uint DefaultPriority;
            public uint StartTime;
            public uint UntilTime;
            public uint Status;
            public uint cJobs;
            public uint AveragePPM;
        }

        public class PrinterHelper : IDisposable
        {
            private static object oMissing = Missing.Value;
            private static object oTrue = true;
            private static object oFalse = false;
            private static object oStory = WdUnits.wdStory;
            private static object oMove = WdMovementType.wdMove;

            public void AddCustomPaperSize(string printerName, string paperName, float width, float height)
            {
                if (PlatformID.Win32NT == Environment.OSVersion.Platform)
                {
                    StringBuilder builder;
                    MSDocPrinter.structPrinterDefaults pd = new MSDocPrinter.structPrinterDefaults();
                    IntPtr zero = IntPtr.Zero;
                    if (!OpenPrinter(printerName, out zero, ref pd))
                    {
                        builder = new StringBuilder();
                        builder.AppendFormat("打开打印机{0} 时出现异常!, 系统错误号: {1}", printerName, GetLastError());
                        throw new ApplicationException(builder.ToString());
                    }
                    try
                    {
                        DeleteForm(zero, paperName);
                        MSDocPrinter.structFormInfo1 form = new MSDocPrinter.structFormInfo1 {
                            Flags = 0,
                            pName = paperName,
                            Size = { 
                                width = (int) (width * 100.0),
                                height = (int) (height * 100.0)
                            },
                            ImageableArea = { left = 0 }
                        };
                        form.ImageableArea.right = form.Size.width;
                        form.ImageableArea.top = 0;
                        form.ImageableArea.bottom = form.Size.height;
                        if (!AddForm(zero, 1, ref form))
                        {
                            builder = new StringBuilder();
                            builder.AppendFormat("添加纸张{0}时发生错误!, 系统错误号: {1}", paperName, GetLastError());
                            throw new ApplicationException(builder.ToString());
                        }
                    }
                    finally
                    {
                        ClosePrinter(zero);
                    }
                }
                else
                {
                    MSDocPrinter.structDevMode pDevMode = new MSDocPrinter.structDevMode();
                    IntPtr hDC = CreateDC(null, printerName, null, ref pDevMode);
                    if (hDC != IntPtr.Zero)
                    {
                        pDevMode.dmFields = 14;
                        pDevMode.dmPaperSize = 0x100;
                        pDevMode.dmPaperWidth = (short) ((width * 2.54) * 10000.0);
                        pDevMode.dmPaperLength = (short) ((height * 2.54) * 10000.0);
                        ResetDC(hDC, ref pDevMode);
                        DeleteDC(hDC);
                    }
                }
            }

            [SuppressUnmanagedCodeSecurity, DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool AddForm(IntPtr phPrinter, [MarshalAs(UnmanagedType.I4)] int level, ref MSDocPrinter.structFormInfo1 form);
            public static bool CheckPrinterValid(string printername)
            {
                if (printername.Length < 1)
                {
                    return false;
                }
                MSDocPrinter.ePrinterState printerStatus = GetPrinterStatus(printername);
                return ((printerStatus == MSDocPrinter.ePrinterState.Ready) || (printerStatus == MSDocPrinter.ePrinterState.Busy));
            }

            [SuppressUnmanagedCodeSecurity, DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool ClosePrinter(IntPtr phPrinter);
            [SuppressUnmanagedCodeSecurity, DllImport("GDI32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern IntPtr CreateDC([MarshalAs(UnmanagedType.LPTStr)] string pDrive, [MarshalAs(UnmanagedType.LPTStr)] string pName, [MarshalAs(UnmanagedType.LPTStr)] string pOutput, ref MSDocPrinter.structDevMode pDevMode);
            [SuppressUnmanagedCodeSecurity, DllImport("GDI32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool DeleteDC(IntPtr hDC);
            [SuppressUnmanagedCodeSecurity, DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool DeleteForm(IntPtr phPrinter, [MarshalAs(UnmanagedType.LPTStr)] string pName);
            public void Dispose()
            {
            }

            [DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, SetLastError=true, ExactSpelling=true)]
            internal static extern bool EndDocPrinter(IntPtr hPrinter);
            [DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, SetLastError=true, ExactSpelling=true)]
            internal static extern bool EndPagePrinter(IntPtr hPrinter);
            private static bool ExecuteReplace(Find find, string key, string val) => 
                ExecuteReplace(find, key, val, WdReplace.wdReplaceAll);

            private static bool ExecuteReplace(Find find, object key, object val, object objReplaceOption)
            {
                object oTrue = MSDocPrinter.PrinterHelper.oTrue;
                return find.Execute(ref key, ref oMissing, ref MSDocPrinter.PrinterHelper.oTrue, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oTrue, ref val, ref objReplaceOption, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            }

            public static string GetDefaultPrinter()
            {
                StringBuilder pszBuffer = new StringBuilder(0x800);
                int capacity = pszBuffer.Capacity;
                GetDefaultPrinter(pszBuffer, ref capacity);
                return pszBuffer.ToString();
            }

            [DllImport("winspool.drv", CharSet=CharSet.Auto, SetLastError=true)]
            private static extern bool GetDefaultPrinter(StringBuilder pszBuffer, ref int pcchBuffer);
            [SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll", CallingConvention=CallingConvention.StdCall, ExactSpelling=true)]
            internal static extern int GetLastError();
            [DllImport("winspool.Drv", EntryPoint="GetPrinterA", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
            internal static extern bool GetPrinter(IntPtr hPrinter, int dwLevel, IntPtr pPrinter, int dwBuf, out int dwNeeded);
            public static List<string> GetPrinterList()
            {
                List<string> list = new List<string>();
                if (PrinterSettings.InstalledPrinters.Count >= 1)
                {
                    foreach (string str in PrinterSettings.InstalledPrinters)
                    {
                        list.Add(str);
                    }
                }
                return list;
            }

            public static MSDocPrinter.ePrinterState GetPrinterStatus(string PrinterName) => 
                ((MSDocPrinter.ePrinterState) GetPrinterStatusInt(PrinterName));

            internal static int GetPrinterStatusInt(string PrinterName)
            {
                int num = 0;
                if (!OpenPrinter(PrinterName, out IntPtr ptr, IntPtr.Zero))
                {
                    return 0x1000;
                }
                int dwNeeded = 0;
                bool flag = GetPrinter(ptr, 2, IntPtr.Zero, 0, out dwNeeded);
                if (dwNeeded < 1)
                {
                    ClosePrinter(ptr);
                    return 0x800;
                }
                IntPtr pPrinter = Marshal.AllocHGlobal(dwNeeded);
                if (!GetPrinter(ptr, 2, pPrinter, dwNeeded, out dwNeeded))
                {
                    ClosePrinter(ptr);
                    return 0x1000;
                }
                MSDocPrinter.PRINTER_INFO_2 printer_info_ = new MSDocPrinter.PRINTER_INFO_2();
                printer_info_ = (MSDocPrinter.PRINTER_INFO_2) Marshal.PtrToStructure(pPrinter, typeof(MSDocPrinter.PRINTER_INFO_2));
                num = Convert.ToInt32(printer_info_.Status);
                Marshal.FreeHGlobal(pPrinter);
                ClosePrinter(ptr);
                return num;
            }

            public PaperSize GetPrintForm(string printerName, string paperName)
            {
                PrinterSettings settings = new PrinterSettings {
                    PrinterName = printerName
                };
                foreach (PaperSize size2 in settings.PaperSizes)
                {
                    if (size2.PaperName.ToLower() == paperName.ToLower())
                    {
                        return size2;
                    }
                }
                return null;
            }

            [DllImport("winspool.Drv", EntryPoint="OpenPrinterA", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
            internal static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);
            [SuppressUnmanagedCodeSecurity, DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPTStr)] string printerName, out IntPtr phPrinter, ref MSDocPrinter.structPrinterDefaults pd);
            public static bool PrintWord(string filename) => 
                PrintWord(filename, 1);

            public static bool PrintWord(string filename, int copies)
            {
                string defaultPrinter = GetDefaultPrinter();
                return PrintWord(filename, defaultPrinter, copies);
            }

            public static bool PrintWord(string filename, int copies, bool bothSide)
            {
                string defaultPrinter = GetDefaultPrinter();
                return PrintWord(filename, defaultPrinter, copies, bothSide);
            }

            public static bool PrintWord(string filename, string printerName, int copies) => 
                PrintWord(filename, printerName, copies, new Dictionary<string, string>(), null);

            public static bool PrintWord(string filename, string printerName, int copies, bool bothSide) => 
                PrintWord(filename, printerName, copies, new Dictionary<string, string>(), null, bothSide);

            public static bool PrintWord(string filename, string printerName, int copies, Dictionary<string, string> tempValues, PaperSize ps) => 
                ((!string.IsNullOrEmpty(printerName) && CheckPrinterValid(printerName)) && PrintWordAuto(printerName, filename, copies, tempValues, ps));

            public static bool PrintWord(string filename, string printerName, int copies, Dictionary<string, string> tempValues, PaperSize ps, bool bothside)
            {
                if (!string.IsNullOrEmpty(printerName))
                {
                    VwfscnApplication.Current.LogWriter.Info("printerName: " + printerName);
                    if (CheckPrinterValid(printerName))
                    {
                        if (bothside)
                        {
                            return PrintWordAutoBySpire(printerName, filename, copies, tempValues, ps);
                        }
                        return PrintWordAuto(printerName, filename, copies, tempValues, ps);
                    }
                }
                return false;
            }

            private static bool PrintWordAuto(string printerName, string filename, int copies, Dictionary<string, string> tempValues, PaperSize ps)
            {
                _Application application = new ApplicationClass {
                    Visible = false,
                    DisplayAlerts = WdAlertLevel.wdAlertsNone
                };
                object fileName = filename;
                Document document = application.Documents.Open(ref fileName, ref oMissing, ref oTrue, ref oFalse, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                Shapes shapes = document.Shapes;
                foreach (string str in tempValues.Keys)
                {
                    foreach (Shape shape in shapes)
                    {
                        if (str.Trim().Equals(shape.TextFrame.TextRange.Text.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            shape.TextFrame.TextRange.Text = tempValues[str];
                            break;
                        }
                    }
                }
                if ((ps != null) && !string.IsNullOrWhiteSpace(ps.PaperName))
                {
                    using (MSDocPrinter.PrinterHelper helper = new MSDocPrinter.PrinterHelper())
                    {
                        helper.SetPrintForm(printerName, ps.PaperName, (float) ps.Width, (float) ps.Height);
                    }
                }
                application.ActivePrinter = printerName;
                object background = false;
                object obj4 = copies;
                document.PrintOut(ref background, ref oFalse, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref obj4, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                object wdDoNotSaveChanges = WdSaveOptions.wdDoNotSaveChanges;
                document.Close(ref wdDoNotSaveChanges, ref oMissing, ref oMissing);
                application.Quit(ref wdDoNotSaveChanges, ref oMissing, ref oMissing);
                document = null;
                application = null;
                return true;
            }

            private static bool PrintWordAutoBySpire(string printerName, string filename, int copies, Dictionary<string, string> tempValues, PaperSize ps)
            {
                _Application application = new ApplicationClass {
                    Visible = false,
                    DisplayAlerts = WdAlertLevel.wdAlertsNone
                };
                object fileName = filename;
                Document document = application.Documents.Open(ref fileName, ref oMissing, ref oTrue, ref oFalse, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                Shapes shapes = document.Shapes;
                foreach (string str in tempValues.Keys)
                {
                    foreach (Shape shape in shapes)
                    {
                        if (str.Trim().Equals(shape.TextFrame.TextRange.Text.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            shape.TextFrame.TextRange.Text = tempValues[str];
                            break;
                        }
                    }
                }
                if ((ps != null) && !string.IsNullOrWhiteSpace(ps.PaperName))
                {
                    using (MSDocPrinter.PrinterHelper helper = new MSDocPrinter.PrinterHelper())
                    {
                        helper.SetPrintForm(printerName, ps.PaperName, (float) ps.Width, (float) ps.Height);
                    }
                }
                string str2 = Path.GetTempFileName() + new FileInfo(filename).Extension;
                VwfscnApplication.Current.LogWriter.Info("TempFile:" + str2);
                object obj4 = str2;
                document.SaveAs2(ref obj4, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing, ref Type.Missing);
                object wdDoNotSaveChanges = WdSaveOptions.wdDoNotSaveChanges;
                document.Close(ref wdDoNotSaveChanges, ref oMissing, ref oMissing);
                application.Quit(ref wdDoNotSaveChanges, ref oMissing, ref oMissing);
                document = null;
                application = null;
                Document document2 = new Document();
                document2.LoadFromFile(str2);
                PrinterSettings settings = new PrinterSettings {
                    Copies = Convert.ToInt16(copies),
                    Duplex = Duplex.Vertical,
                    PrinterName = printerName
                };
                PrintDocument document3 = document2.get_PrintDocument();
                document3.PrinterSettings = settings;
                document3.DocumentName = filename;
                document3.Print();
                document3.Dispose();
                document3 = null;
                document2.Close();
                document2.Dispose();
                document2 = null;
                return true;
            }

            [SuppressUnmanagedCodeSecurity, DllImport("GDI32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern IntPtr ResetDC(IntPtr hDC, ref MSDocPrinter.structDevMode pDevMode);
            [DllImport("Winspool.drv", CharSet=CharSet.Auto, SetLastError=true)]
            public static extern bool SetDefaultPrinter(string printerName);
            [SuppressUnmanagedCodeSecurity, DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
            internal static extern bool SetForm(IntPtr phPrinter, [MarshalAs(UnmanagedType.LPTStr)] string pName, [MarshalAs(UnmanagedType.I4)] int level, ref MSDocPrinter.structFormInfo1 form);
            public void SetPrintForm(string printerName, string paperName, float width, float height)
            {
                if (PlatformID.Win32NT == Environment.OSVersion.Platform)
                {
                    MSDocPrinter.structPrinterDefaults pd = new MSDocPrinter.structPrinterDefaults();
                    IntPtr zero = IntPtr.Zero;
                    if (OpenPrinter(printerName, out zero, ref pd))
                    {
                        try
                        {
                            MSDocPrinter.structFormInfo1 form = new MSDocPrinter.structFormInfo1 {
                                Flags = 0,
                                pName = paperName,
                                Size = { 
                                    width = (int) (width * 100.0),
                                    height = (int) (height * 100.0)
                                },
                                ImageableArea = { left = 0 }
                            };
                            form.ImageableArea.right = form.Size.width;
                            form.ImageableArea.top = 0;
                            form.ImageableArea.bottom = form.Size.height;
                            bool flag = false;
                            if (this.GetPrintForm(printerName, paperName) != null)
                            {
                                flag = SetForm(zero, paperName, 1, ref form);
                            }
                            else
                            {
                                this.AddCustomPaperSize(printerName, paperName, width, height);
                                flag = true;
                            }
                            if (!flag)
                            {
                                StringBuilder builder = new StringBuilder();
                                builder.AppendFormat("添加纸张{0}时发生错误!, 系统错误号: {1}", paperName, GetLastError());
                                MessageBox.Show(builder.ToString());
                            }
                        }
                        finally
                        {
                            ClosePrinter(zero);
                        }
                    }
                }
            }

            [DllImport("winspool.Drv", EntryPoint="StartDocPrinterA", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
            internal static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In, MarshalAs(UnmanagedType.LPStruct)] MSDocPrinter.DOCINFOA di);
            [DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, SetLastError=true, ExactSpelling=true)]
            internal static extern bool StartPagePrinter(IntPtr hPrinter);
            [DllImport("winspool.Drv", CallingConvention=CallingConvention.StdCall, SetLastError=true, ExactSpelling=true)]
            internal static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);
        }

        [Flags]
        internal enum PrinterStatus
        {
            PRINTER_STATUS_BUSY = 0x200,
            PRINTER_STATUS_DOOR_OPEN = 0x400000,
            PRINTER_STATUS_ERROR = 2,
            PRINTER_STATUS_INITIALIZING = 0x8000,
            PRINTER_STATUS_IO_ACTIVE = 0x100,
            PRINTER_STATUS_MANUAL_FEED = 0x20,
            PRINTER_STATUS_NO_TONER = 0x40000,
            PRINTER_STATUS_NOT_AVAILABLE = 0x1000,
            PRINTER_STATUS_OFFLINE = 0x80,
            PRINTER_STATUS_OUT_OF_MEMORY = 0x200000,
            PRINTER_STATUS_OUTPUT_BIN_FULL = 0x800,
            PRINTER_STATUS_PAGE_PUNT = 0x80000,
            PRINTER_STATUS_PAPER_JAM = 8,
            PRINTER_STATUS_PAPER_OUT = 0x10,
            PRINTER_STATUS_PAPER_PROBLEM = 0x40,
            PRINTER_STATUS_PAUSED = 1,
            PRINTER_STATUS_PENDING_DELETION = 4,
            PRINTER_STATUS_PRINTING = 0x400,
            PRINTER_STATUS_PROCESSING = 0x4000,
            PRINTER_STATUS_TONER_LOW = 0x20000,
            PRINTER_STATUS_USER_INTERVENTION = 0x100000,
            PRINTER_STATUS_WAITING = 0x20000000,
            PRINTER_STATUS_WARMING_UP = 0x10000
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal struct structDevMode
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=0x20)]
            public string dmDeviceName;
            [MarshalAs(UnmanagedType.U2)]
            public short dmSpecVersion;
            [MarshalAs(UnmanagedType.U2)]
            public short dmDriverVersion;
            [MarshalAs(UnmanagedType.U2)]
            public short dmSize;
            [MarshalAs(UnmanagedType.U2)]
            public short dmDriverExtra;
            [MarshalAs(UnmanagedType.U4)]
            public int dmFields;
            [MarshalAs(UnmanagedType.I2)]
            public short dmOrientation;
            [MarshalAs(UnmanagedType.I2)]
            public short dmPaperSize;
            [MarshalAs(UnmanagedType.I2)]
            public short dmPaperLength;
            [MarshalAs(UnmanagedType.I2)]
            public short dmPaperWidth;
            [MarshalAs(UnmanagedType.I2)]
            public short dmScale;
            [MarshalAs(UnmanagedType.I2)]
            public short dmCopies;
            [MarshalAs(UnmanagedType.I2)]
            public short dmDefaultSource;
            [MarshalAs(UnmanagedType.I2)]
            public short dmPrintQuality;
            [MarshalAs(UnmanagedType.I2)]
            public short dmColor;
            [MarshalAs(UnmanagedType.I2)]
            public short dmDuplex;
            [MarshalAs(UnmanagedType.I2)]
            public short dmYResolution;
            [MarshalAs(UnmanagedType.I2)]
            public short dmTTOption;
            [MarshalAs(UnmanagedType.I2)]
            public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=0x20)]
            public string dmFormName;
            [MarshalAs(UnmanagedType.U2)]
            public short dmLogPixels;
            [MarshalAs(UnmanagedType.U4)]
            public int dmBitsPerPel;
            [MarshalAs(UnmanagedType.U4)]
            public int dmPelsWidth;
            [MarshalAs(UnmanagedType.U4)]
            public int dmPelsHeight;
            [MarshalAs(UnmanagedType.U4)]
            public int dmNup;
            [MarshalAs(UnmanagedType.U4)]
            public int dmDisplayFrequency;
            [MarshalAs(UnmanagedType.U4)]
            public int dmICMMethod;
            [MarshalAs(UnmanagedType.U4)]
            public int dmICMIntent;
            [MarshalAs(UnmanagedType.U4)]
            public int dmMediaType;
            [MarshalAs(UnmanagedType.U4)]
            public int dmDitherType;
            [MarshalAs(UnmanagedType.U4)]
            public int dmReserved1;
            [MarshalAs(UnmanagedType.U4)]
            public int dmReserved2;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal struct structFormInfo1
        {
            [MarshalAs(UnmanagedType.I4)]
            public int Flags;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pName;
            public MSDocPrinter.structSize Size;
            public MSDocPrinter.structRect ImageableArea;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal struct structPrinterDefaults
        {
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDatatype;
            public IntPtr pDevMode;
            [MarshalAs(UnmanagedType.I4)]
            public int DesiredAccess;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal struct structRect
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
        internal struct structSize
        {
            public int width;
            public int height;
        }
    }
}

