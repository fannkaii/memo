﻿namespace VWFSCN.IT.DeMortagage.MRPrinter
{
    using Spire.Doc;
    using Spire.Doc.Fields;
    using Spire.Pdf;
    using Spire.Pdf.Graphics;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Configuration;
    using System.Diagnostics;
    using System.Drawing;
    using System.Drawing.Printing;
    using System.Threading;
    using System.Windows.Forms;
    using VWFSCN.IT.Common;
    using VWFSCN.IT.DeMortagage.MRPrinter.PrintSvc;

    public class frmDocPrint : Form, IPrintStatus
    {
        private const string StrWaiting = "Waiting for print document...";
        private const string StrStoped = "Document printing Stopped...";
        private const string StrCfgPrinter = "DocPrinterName";
        private const string StrCfgPrinterEnable = "DoDocPrint";
        private const string StrLeaderPageTemp = "LeaderPageTemp.docx";
        private int _timeSpan = 60;
        private bool _isWorking = true;
        private Thread _threadDoc;
        private bool _docIsWorking;
        private bool _haveNext;
        private string _dkx;
        private PrintServiceClient _client = new PrintServiceClient();
        private string _runas = string.Empty;
        private IContainer components = null;
        private ProgressBar progressBar1;
        private Label label1;
        private Button button1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;

        public frmDocPrint()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ("stop".Equals(this.button1.Text.ToLower()))
            {
                this.Stop();
            }
            else
            {
                this.Start();
            }
        }

        private void checkDoc()
        {
            while (this._isWorking)
            {
                if (!this._docIsWorking)
                {
                    try
                    {
                        this.PrintJob();
                    }
                    catch (Exception exception)
                    {
                        VwfscnApplication.Current.LogWriter.Error(exception);
                        this.showProcessInfo(exception.Message);
                    }
                    finally
                    {
                        this._docIsWorking = false;
                    }
                }
                Thread.Sleep((int) (this._timeSpan * 0x3e8));
            }
        }

        public void CloseJob()
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            this._isWorking = false;
            if (this._threadDoc.IsAlive)
            {
                this._threadDoc.Abort();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this._dkx = this.RunAsUser;
            string str = ConfigurationManager.get_AppSettings().Get("timeSpan");
            this._timeSpan = Convert.ToInt32(str);
            if (this._timeSpan == 0)
            {
                this._timeSpan = 60;
            }
            if ("true".Equals(ConfigurationManager.get_AppSettings().Get("DoDocPrint")))
            {
                this.Start();
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.progressBar1 = new ProgressBar();
            this.label1 = new Label();
            this.button1 = new Button();
            this.contextMenuStrip1 = new ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.progressBar1.Dock = DockStyle.Top;
            this.progressBar1.Location = new Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0x124, 10);
            this.progressBar1.Style = ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 5;
            this.progressBar1.Visible = false;
            this.label1.BackColor = SystemColors.Control;
            this.label1.Dock = DockStyle.Fill;
            this.label1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0, 10);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x124, 0x3d);
            this.label1.TabIndex = 4;
            this.label1.TextAlign = ContentAlignment.MiddleCenter;
            this.button1.BackColor = SystemColors.ControlDark;
            this.button1.Dock = DockStyle.Bottom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = FlatStyle.Flat;
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.ForeColor = Color.White;
            this.button1.Location = new Point(0, 0x47);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x124, 0x1b);
            this.button1.TabIndex = 3;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.contextMenuStrip1.Items.AddRange(new ToolStripItem[] { this.toolStripMenuItem1 });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new Size(0x61, 0x1a);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x60, 0x16);
            this.toolStripMenuItem1.Text = "Stop";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x124, 0x62);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.progressBar1);
            base.Controls.Add(this.button1);
            base.FormBorderStyle = FormBorderStyle.None;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "frmDocPrint";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            this.Text = "frmDocPrint";
            base.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
            base.Load += new EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private string NetPath(string filePath)
        {
            string str = ConfigurationManager.get_AppSettings().Get("MRDocNetPath");
            int startIndex = filePath.LastIndexOf(@"\");
            if (startIndex > 1)
            {
                startIndex = filePath.LastIndexOf(@"\", (int) (startIndex - 1));
            }
            if (startIndex > 0)
            {
                string str2 = filePath.Substring(startIndex);
                return (str + str2);
            }
            return filePath;
        }

        private void PrintJob()
        {
            VwfscnApplication.Current.LogWriter.Info("Print job");
            this._docIsWorking = true;
            this._haveNext = true;
            while (this._haveNext)
            {
                string str = ConfigurationManager.get_AppSettings().Get("ExpressPrinterName");
                if (!(string.IsNullOrWhiteSpace(str) || !MSDocPrinter.PrinterHelper.GetDefaultPrinter().Equals(str)))
                {
                    this.showProcessInfo("Please replace the default printer, Current one is used to print Express Bill only.");
                    break;
                }
                int num = this._client.DocMax(this._dkx);
                this.showProgressBar(num);
                VwfscnApplication.Current.LogWriter.Info($"There are {num} documents to be printed.");
                LeaderPage lpData = new LeaderPage();
                DocTask[] taskArray = this._client.DocPopupLeader(out lpData, this._dkx);
                if (taskArray == null)
                {
                    this._haveNext = false;
                    this.SetWaiting();
                }
                else
                {
                    string str2 = this.PrintLeaderPageTemplate(lpData);
                    VwfscnApplication.Current.LogWriter.Info("resultLPT: " + str2);
                    if (!string.Empty.Equals(str2))
                    {
                        VwfscnApplication.Current.LogWriter.Error($"Leader Page Print Exception: {str2}");
                    }
                    foreach (DocTask task in taskArray)
                    {
                        string fileName = this.NetPath(task.FilePath);
                        VwfscnApplication.Current.LogWriter.Info("File Path: " + fileName);
                        string str4 = this.PrintProcess(fileName, task.Copies, task.BothSide);
                        VwfscnApplication.Current.LogWriter.Debug($"The document ({fileName}) is sent to print, {task.Copies} copies.");
                        if (!string.Empty.Equals(str4))
                        {
                            task.FilePath = fileName;
                            this._client.PrintErrorLog(task, str4);
                            VwfscnApplication.Current.LogWriter.Error($"{str4}");
                        }
                    }
                }
            }
            this.showProgressBar(0);
            this._docIsWorking = false;
        }

        private string PrintLeaderPageTemplate(LeaderPage task)
        {
            string message = string.Empty;
            PrintDialog dialog = new PrintDialog {
                AllowPrintToFile = true,
                AllowCurrentPage = true,
                AllowSomePages = true,
                UseEXDialog = true,
                PrinterSettings = { Copies = 1 }
            };
            string str2 = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
            if (!string.IsNullOrEmpty(str2))
            {
                dialog.PrinterSettings.PrinterName = str2;
            }
            dialog.PrinterSettings.Collate = false;
            Document document = new Document();
            try
            {
                document.LoadFromFile("LeaderPageTemp.docx");
                foreach (TextBox box in document.get_TextBoxes())
                {
                    string[] strArray;
                    int num;
                    int num2;
                    switch (box.get_Body().get_Paragraphs().get_Item(0).get_Text().Trim().Substring(0, 1))
                    {
                        case "1":
                        {
                            box.get_Body().get_Paragraphs().get_Item(0).set_Text(task.DealerCode);
                            continue;
                        }
                        case "2":
                        {
                            box.get_Body().get_Paragraphs().get_Item(0).set_Text(task.Dealer);
                            continue;
                        }
                        case "3":
                            strArray = task.DocumentsList.Split(new char[] { '|' });
                            num = box.get_Body().get_Paragraphs().get_Count();
                            num2 = 0;
                            goto Label_01FE;

                        case "4":
                        {
                            int allPages = task.AllPages;
                            box.get_Body().get_Paragraphs().get_Item(0).set_Text(allPages.ToString());
                            continue;
                        }
                        case "5":
                        {
                            box.get_Body().get_Paragraphs().get_Item(0).set_Text(task.City);
                            continue;
                        }
                        case "6":
                        {
                            box.get_Body().get_Paragraphs().get_Item(0).set_Text(task.SalesArea);
                            continue;
                        }
                        default:
                        {
                            continue;
                        }
                    }
                Label_01E9:
                    box.get_Body().AddParagraph();
                    num2++;
                Label_01FE:
                    if (num2 < (strArray.Length - num))
                    {
                        goto Label_01E9;
                    }
                    for (num2 = 0; num2 < strArray.Length; num2++)
                    {
                        box.get_Body().get_Paragraphs().get_Item(num2).set_Text(strArray[num2]);
                    }
                }
                document.set_PrintDialog(dialog);
                document.get_PrintDocument().Print();
                VwfscnApplication.Current.LogWriter.Info($"Print Leader Page: {task.DealerCode} - {task.Dealer}, {task.AllPages.ToString()} done.");
            }
            catch (Exception exception)
            {
                VwfscnApplication.Current.LogWriter.Error(exception);
                message = exception.Message;
            }
            finally
            {
                document.Close();
                dialog.Dispose();
            }
            return message;
        }

        private string PrintProcess(string fileName, int copies)
        {
            string str = string.Empty;
            string[] strArray = fileName.Split(new char[] { '\\' });
            str = fileName.Substring(fileName.LastIndexOf('.'));
            if (str.ToLower().Contains("jpg"))
            {
                return this.PrintProcessJpg(fileName, copies);
            }
            if (str.ToLower().Contains("pdf"))
            {
                return this.PrintProcessPdf(fileName, copies);
            }
            if (str.ToLower().Contains("doc"))
            {
                return this.PrintProcessDoc(fileName, copies);
            }
            string msg = $"Error file type, can not be printed. ({fileName}) ";
            VwfscnApplication.Current.LogWriter.Error(msg);
            return msg;
        }

        private string PrintProcess(string fileName, int copies, bool bothSide)
        {
            VwfscnApplication.Current.LogWriter.Info("PrintProcess(string fileName, int copies, bool bothSide)");
            string str = string.Empty;
            string[] strArray = fileName.Split(new char[] { '\\' });
            str = fileName.Substring(fileName.LastIndexOf('.'));
            if (str.ToLower().Contains("jpg"))
            {
                VwfscnApplication.Current.LogWriter.Info("jpg");
                return this.PrintProcessJpg(fileName, copies);
            }
            if (str.ToLower().Contains("pdf"))
            {
                VwfscnApplication.Current.LogWriter.Info("pdf");
                return this.PrintProcessPdf(fileName, copies, bothSide);
            }
            if (str.ToLower().Contains("doc"))
            {
                VwfscnApplication.Current.LogWriter.Info("doc");
                return this.PrintProcessDoc(fileName, copies, bothSide);
            }
            string msg = $"Error file type, can not be printed. ({fileName}) ";
            VwfscnApplication.Current.LogWriter.Error(msg);
            return msg;
        }

        private string PrintProcessBySystem(string fileName, int copies)
        {
            this.showProcessInfo(fileName);
            try
            {
                for (int i = 0; i < copies; i++)
                {
                    Process process = new Process {
                        StartInfo = { 
                            CreateNoWindow = true,
                            WindowStyle = ProcessWindowStyle.Hidden,
                            UseShellExecute = true,
                            FileName = fileName,
                            Verb = "print"
                        }
                    };
                    process.Start();
                    process.WaitForExit(0x2710);
                    process.Close();
                }
            }
            catch (Exception exception)
            {
                if (exception.InnerException != null)
                {
                    return exception.InnerException.Message;
                }
                return exception.Message;
            }
            finally
            {
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        private string PrintProcessDoc(string fileName, int copies)
        {
            this.showProcessInfo(fileName);
            try
            {
                string str = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
                if (!string.IsNullOrWhiteSpace(str))
                {
                    MSDocPrinter.PrinterHelper.PrintWord(fileName, str, copies, new Dictionary<string, string>(), new PaperSize("A4", 0x33b, 0x491));
                }
                else
                {
                    MSDocPrinter.PrinterHelper.PrintWord(fileName, copies);
                }
            }
            catch (Exception exception)
            {
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (exception.InnerException != null)
                {
                    return exception.InnerException.Message;
                }
                return exception.Message;
            }
            finally
            {
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        private string PrintProcessDoc(string fileName, int copies, bool bs)
        {
            this.showProcessInfo(fileName);
            try
            {
                string str = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
                VwfscnApplication.Current.LogWriter.Info("Print Name:" + str);
                if (!string.IsNullOrWhiteSpace(str))
                {
                    MSDocPrinter.PrinterHelper.PrintWord(fileName, str, copies, new Dictionary<string, string>(), new PaperSize("A4", 0x33b, 0x491), bs);
                }
                else
                {
                    MSDocPrinter.PrinterHelper.PrintWord(fileName, copies, bs);
                }
            }
            catch (Exception exception)
            {
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (exception.InnerException != null)
                {
                    return exception.InnerException.Message;
                }
                return exception.Message;
            }
            finally
            {
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        private string PrintProcessJpg(string fileName, int copies)
        {
            PrintPageEventHandler handler = null;
            this.showProcessInfo(fileName);
            PrintDocument doc = new PrintDocument();
            try
            {
                doc.PrintController = new StandardPrintController();
                doc.DefaultPageSettings.PaperSize = new PaperSize("A4", 0x33b, 0x491);
                doc.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
                doc.PrinterSettings.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
                doc.PrinterSettings.Copies = (short) copies;
                if (handler == null)
                {
                    handler = delegate (object sndr, PrintPageEventArgs args) {
                        Image image = Image.FromFile(fileName);
                        Rectangle marginBounds = args.MarginBounds;
                        if ((((double) image.Width) / ((double) image.Height)) > (((double) marginBounds.Width) / ((double) marginBounds.Height)))
                        {
                            marginBounds.Height = (int) ((((double) image.Height) / ((double) image.Width)) * marginBounds.Width);
                        }
                        else
                        {
                            marginBounds.Width = (int) ((((double) image.Width) / ((double) image.Height)) * marginBounds.Height);
                        }
                        doc.DefaultPageSettings.Landscape = marginBounds.Width > marginBounds.Height;
                        marginBounds.Y = (((PrintDocument) sndr).DefaultPageSettings.PaperSize.Height - marginBounds.Height) / 2;
                        marginBounds.X = (((PrintDocument) sndr).DefaultPageSettings.PaperSize.Width - marginBounds.Width) / 2;
                        args.Graphics.DrawImage(image, marginBounds);
                    };
                }
                doc.PrintPage += handler;
                string str = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
                if (!string.IsNullOrEmpty(str))
                {
                    doc.PrinterSettings.PrinterName = str;
                }
                doc.Print();
            }
            catch (Exception exception)
            {
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (exception.InnerException != null)
                {
                    return exception.InnerException.Message;
                }
                return exception.Message;
            }
            finally
            {
                doc.Dispose();
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        private string PrintProcessPdf(string fileName, int copies)
        {
            this.showProcessInfo(fileName);
            PdfDocument document = new PdfDocument();
            PdfMargins margins = new PdfMargins(0f, 0f, 0f, 0f);
            Margins margins2 = new Margins(0, 0, 0, 0);
            try
            {
                string str = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
                if (!string.IsNullOrEmpty(str))
                {
                    document.get_PrintDocument().PrinterSettings.PrinterName = str;
                }
                document.LoadFromFile(fileName);
                document.get_PrintDocument().PrinterSettings.Copies = (short) copies;
                document.get_PrintDocument().PrinterSettings.Collate = false;
                document.get_PrintDocument().PrinterSettings.Duplex = Duplex.Simplex;
                if (fileName.IndexOf("BOTHSIDES") != -1)
                {
                    document.get_PrintDocument().PrinterSettings.Duplex = Duplex.Vertical;
                }
                document.set_CustomScaling(0x67);
                document.set_PageScaling(3);
                document.get_PageSettings().set_Size(PdfPageSize.A4);
                document.get_PrintDocument().DefaultPageSettings.Margins = margins2;
                document.get_PrintDocument().PrinterSettings.DefaultPageSettings.Margins = margins2;
                document.get_PrintDocument().OriginAtMargins = true;
                document.get_PageSettings().set_Margins(margins);
                document.get_PageSettings().SetMargins(margins.get_Left(), margins.get_Top(), margins.get_Right(), margins.get_Bottom());
                string paperName = document.get_PrintDocument().DefaultPageSettings.PaperSize.PaperName;
                document.get_PrintDocument().Print();
            }
            catch (Exception exception)
            {
                string message;
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (exception.InnerException != null)
                {
                    message = exception.InnerException.Message;
                }
                else
                {
                    message = exception.Message;
                }
                MessageBox.Show(message);
                return message;
            }
            finally
            {
                document.Close();
                document.Dispose();
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        private string PrintProcessPdf(string fileName, int copies, bool bs)
        {
            this.showProcessInfo(fileName);
            PdfDocument document = new PdfDocument();
            PdfMargins margins = new PdfMargins(0f, 0f, 0f, 0f);
            Margins margins2 = new Margins(0, 0, 0, 0);
            try
            {
                string str = ConfigurationManager.get_AppSettings().Get("DocPrinterName");
                if (!string.IsNullOrEmpty(str))
                {
                    document.get_PrintDocument().PrinterSettings.PrinterName = str;
                }
                document.LoadFromFile(fileName);
                document.get_PrintDocument().PrinterSettings.Copies = (short) copies;
                document.get_PrintDocument().PrinterSettings.Collate = false;
                document.get_PrintDocument().PrinterSettings.Duplex = Duplex.Simplex;
                if ((fileName.IndexOf("BOTHSIDES") != -1) || bs)
                {
                    document.get_PrintDocument().PrinterSettings.Duplex = Duplex.Vertical;
                }
                document.set_CustomScaling(0x67);
                document.set_PageScaling(3);
                document.get_PageSettings().set_Size(PdfPageSize.A4);
                document.get_PrintDocument().DefaultPageSettings.Margins = margins2;
                document.get_PrintDocument().PrinterSettings.DefaultPageSettings.Margins = margins2;
                document.get_PrintDocument().OriginAtMargins = true;
                document.get_PageSettings().set_Margins(margins);
                document.get_PageSettings().SetMargins(margins.get_Left(), margins.get_Top(), margins.get_Right(), margins.get_Bottom());
                string paperName = document.get_PrintDocument().DefaultPageSettings.PaperSize.PaperName;
                document.get_PrintDocument().Print();
            }
            catch (Exception exception)
            {
                string message;
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (exception.InnerException != null)
                {
                    message = exception.InnerException.Message;
                }
                else
                {
                    message = exception.Message;
                }
                MessageBox.Show(message);
                return message;
            }
            finally
            {
                document.Close();
                document.Dispose();
                this.showProcessInfo(string.Empty);
            }
            return string.Empty;
        }

        public void ResetSize()
        {
            this.Refresh();
        }

        private void SetWaiting()
        {
            Action<string> method = delegate (string n) {
                if (this.label1 != null)
                {
                    try
                    {
                        this.label1.Text = n;
                    }
                    catch (Exception)
                    {
                    }
                }
            };
            this.label1.Invoke(method, new object[] { "Waiting for print document..." });
        }

        private void showProcessInfo(string msg)
        {
            Action<string> method = n => this.label1.Text = n;
            this.label1.Invoke(method, new object[] { msg });
        }

        private void showProgressBar(int value)
        {
            Action<int> method = delegate (int n) {
                if (this.progressBar1 != null)
                {
                    if (n == 0)
                    {
                        this.progressBar1.Visible = false;
                    }
                    else if (!this.progressBar1.Visible)
                    {
                        this.progressBar1.Visible = true;
                        this.progressBar1.Maximum = n;
                        this.progressBar1.Minimum = 1;
                        this.progressBar1.Value = 1;
                        this.progressBar1.Step = 1;
                    }
                    else if (n > this.progressBar1.Maximum)
                    {
                        this.progressBar1.Maximum = n;
                    }
                    else
                    {
                        try
                        {
                            this.progressBar1.Value = this.progressBar1.Maximum - n;
                        }
                        catch (Exception)
                        {
                        }
                    }
                }
            };
            this.progressBar1.Invoke(method, new object[] { value });
        }

        public void Start()
        {
            this._isWorking = true;
            this.button1.BackColor = SystemColors.ControlDark;
            this.label1.BackColor = SystemColors.Control;
            this.button1.ForeColor = Color.White;
            this.button1.Text = "Stop";
            this.label1.Text = "Waiting for print document...";
            this._threadDoc = new Thread(new ThreadStart(this.checkDoc));
            this._threadDoc.Start();
            this.toolStripMenuItem1.Text = this.button1.Text;
        }

        public void Stop()
        {
            this._isWorking = false;
            this._haveNext = false;
            this.button1.Text = "Start";
            this.button1.BackColor = SystemColors.Control;
            this.label1.BackColor = SystemColors.ControlDark;
            this.button1.ForeColor = Color.Black;
            this.Cursor = Cursors.WaitCursor;
            Thread.Sleep((int) (this._timeSpan * 0x3e8));
            this.Cursor = Cursors.Default;
            this.toolStripMenuItem1.Text = this.button1.Text;
            this.label1.Text = "Document printing Stopped...";
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.button1_Click(sender, e);
        }

        public string RunAsUser
        {
            get => 
                this._runas;
            set => 
                (this._runas = value);
        }
    }
}

