﻿namespace VWFSCN.IT.DeMortagage.MRPrinter
{
    using System;

    internal interface IPrintStatus
    {
        void CloseJob();
        void ResetSize();
        void Start();
        void Stop();

        string RunAsUser { get; set; }
    }
}

