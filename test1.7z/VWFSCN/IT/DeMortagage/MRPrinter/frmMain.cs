﻿namespace VWFSCN.IT.DeMortagage.MRPrinter
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Management;
    using System.Windows.Forms;
    using VWFSCN.IT.Common;

    public class frmMain : Form
    {
        private IPrintStatus _docPrint = null;
        private IPrintStatus _expressPrint = null;
        private IContainer components = null;
        private NotifyIcon notifyIcon1;
        private ToolStripContainer toolStripContainer1;
        private SplitContainer splitContainer1;
        private Label label1;
        private SplitContainer spc;
        private ToolStrip toolStrip1;
        private ToolStripButton tsbAllStart;
        private ToolStripButton tsbAllStop;
        private ToolStripSeparator toolStripSeparator1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem toolStripMenuItem2;

        public frmMain()
        {
            this.InitializeComponent();
        }

        private void AddToPanel(Panel target, Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            if (form is IPrintStatus)
            {
                ((IPrintStatus) form).RunAsUser = GetProcessUserName(GetPid());
            }
            target.Controls.Add(form);
            form.Show();
        }

        private void btnAllStart_Click(object sender, EventArgs e)
        {
            if (this._docPrint != null)
            {
                this._docPrint.Start();
            }
            if (this._expressPrint != null)
            {
                this._expressPrint.Start();
            }
        }

        private void btnAllStop_Click(object sender, EventArgs e)
        {
            if (this._docPrint != null)
            {
                this._docPrint.Stop();
            }
            Application.DoEvents();
            if (this._expressPrint != null)
            {
                this._expressPrint.Stop();
            }
            Application.DoEvents();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            string text = "Note that close the current form, will influence the MR system document and Express printing. Continue?";
            if (DialogResult.Yes != MessageBox.Show(text, "Warnning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2))
            {
                e.Cancel = true;
            }
            else
            {
                if (this._docPrint != null)
                {
                    this._docPrint.CloseJob();
                }
                if (this._expressPrint != null)
                {
                    this._expressPrint.CloseJob();
                }
                this.notifyIcon1.Visible = false;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            base.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - base.Width, Screen.PrimaryScreen.WorkingArea.Height - base.Height);
            this.Text = $"MR/DMR Printer({GetProcessUserName(GetPid())}) ";
            try
            {
                if (this._docPrint == null)
                {
                    this._docPrint = new frmDocPrint();
                }
                this.AddToPanel(this.spc.Panel1, (Form) this._docPrint);
                if (this._expressPrint == null)
                {
                    this._expressPrint = new frmExpressPrint();
                }
                this.AddToPanel(this.spc.Panel2, (Form) this._expressPrint);
            }
            catch (Exception exception)
            {
                VwfscnApplication.Current.LogWriter.Error(exception);
                if (MessageBox.Show($"An error occurred. {exception.Message} 
 {"Press 'OK' to close."}", this.Text, MessageBoxButtons.OK) == DialogResult.OK)
                {
                    base.Close();
                }
            }
        }

        private void frmMain_SizeChanged(object sender, EventArgs e)
        {
            if (base.WindowState == FormWindowState.Minimized)
            {
                base.ShowInTaskbar = false;
                this.notifyIcon1.Visible = true;
            }
            else
            {
                base.ShowInTaskbar = true;
                this.notifyIcon1.Visible = true;
            }
        }

        private static int GetPid()
        {
            Process[] processes = Process.GetProcesses();
            string[] strArray = Process.GetCurrentProcess().MainModule.FileName.Split(new char[] { '\\' });
            string str = strArray[strArray.Length - 1];
            foreach (Process process in processes)
            {
                if ((process.ProcessName + ".exe").ToLower() == str.ToLower())
                {
                    return process.Id;
                }
            }
            return 0;
        }

        private static string GetProcessUserName(int pid)
        {
            string str = string.Empty;
            SelectQuery query = new SelectQuery($"select * from Win32_Process where processID={pid}");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
            try
            {
                foreach (ManagementObject obj2 in searcher.Get())
                {
                    ManagementBaseObject inParameters = null;
                    inParameters = obj2.GetMethodParameters("GetOwner");
                    str = obj2.InvokeMethod("GetOwner", inParameters, null)["user"].ToString();
                    goto Label_00AD;
                }
            }
            catch (Exception)
            {
                str = "SYSTEM";
            }
        Label_00AD:
            return $"{Environment.UserDomainName}\{str}";
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(frmMain));
            this.notifyIcon1 = new NotifyIcon(this.components);
            this.toolStripContainer1 = new ToolStripContainer();
            this.splitContainer1 = new SplitContainer();
            this.label1 = new Label();
            this.spc = new SplitContainer();
            this.toolStrip1 = new ToolStrip();
            this.tsbAllStart = new ToolStripButton();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.tsbAllStop = new ToolStripButton();
            this.contextMenuStrip1 = new ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.toolStripMenuItem2 = new ToolStripMenuItem();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.splitContainer1.BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.spc.BeginInit();
            this.spc.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = (Icon) manager.GetObject("notifyIcon1.Icon");
            this.notifyIcon1.Text = "MR Printer";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.DoubleClick += new EventHandler(this.notifyIcon1_DoubleClick);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.splitContainer1);
            this.toolStripContainer1.ContentPanel.Size = new Size(0x1d8, 0x51);
            this.toolStripContainer1.Dock = DockStyle.Fill;
            this.toolStripContainer1.Location = new Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new Size(0x1d8, 0x51);
            this.toolStripContainer1.TabIndex = 2;
            this.toolStripContainer1.Text = "toolStripContainer1";
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            this.splitContainer1.BorderStyle = BorderStyle.FixedSingle;
            this.splitContainer1.Dock = DockStyle.Fill;
            this.splitContainer1.FixedPanel = FixedPanel.Panel1;
            this.splitContainer1.Location = new Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = Orientation.Horizontal;
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Padding = new Padding(10);
            this.splitContainer1.Panel1Collapsed = true;
            this.splitContainer1.Panel1MinSize = 0;
            this.splitContainer1.Panel2.Controls.Add(this.spc);
            this.splitContainer1.Size = new Size(0x1d8, 0x51);
            this.splitContainer1.SplitterDistance = 0x31;
            this.splitContainer1.TabIndex = 2;
            this.label1.Dock = DockStyle.Fill;
            this.label1.ForeColor = Color.DarkBlue;
            this.label1.Location = new Point(10, 10);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x80, 0x1b);
            this.label1.TabIndex = 0;
            this.label1.Text = "This window will auto start with OS. Please do not close this window. ";
            this.spc.BackColor = SystemColors.ControlDarkDark;
            this.spc.BorderStyle = BorderStyle.FixedSingle;
            this.spc.Dock = DockStyle.Fill;
            this.spc.ForeColor = SystemColors.GradientActiveCaption;
            this.spc.Location = new Point(0, 0);
            this.spc.Name = "spc";
            this.spc.Panel1.BackColor = SystemColors.ControlDarkDark;
            this.spc.Panel1.ForeColor = SystemColors.ControlText;
            this.spc.Panel2.BackColor = SystemColors.ControlDarkDark;
            this.spc.Panel2.ForeColor = SystemColors.ControlText;
            this.spc.Size = new Size(0x1d8, 0x51);
            this.spc.SplitterDistance = 0xeb;
            this.spc.TabIndex = 1;
            this.toolStrip1.Dock = DockStyle.None;
            this.toolStrip1.Items.AddRange(new ToolStripItem[] { this.tsbAllStart, this.toolStripSeparator1, this.tsbAllStop });
            this.toolStrip1.LayoutStyle = ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new Size(0x1d8, 0x17);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Visible = false;
            this.tsbAllStart.DisplayStyle = ToolStripItemDisplayStyle.Text;
            this.tsbAllStart.Image = (Image) manager.GetObject("tsbAllStart.Image");
            this.tsbAllStart.ImageTransparentColor = Color.Magenta;
            this.tsbAllStart.Name = "tsbAllStart";
            this.tsbAllStart.Size = new Size(0x23, 0x13);
            this.tsbAllStart.Text = "&Start";
            this.tsbAllStart.Click += new EventHandler(this.btnAllStart_Click);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(6, 0x17);
            this.tsbAllStop.DisplayStyle = ToolStripItemDisplayStyle.Text;
            this.tsbAllStop.Image = (Image) manager.GetObject("tsbAllStop.Image");
            this.tsbAllStop.ImageTransparentColor = Color.Magenta;
            this.tsbAllStop.Name = "tsbAllStop";
            this.tsbAllStop.Size = new Size(0x23, 0x13);
            this.tsbAllStop.Text = "S&top";
            this.tsbAllStop.TextAlign = ContentAlignment.MiddleRight;
            this.tsbAllStop.ToolTipText = "Stop print jobs";
            this.tsbAllStop.Click += new EventHandler(this.btnAllStop_Click);
            this.contextMenuStrip1.Items.AddRange(new ToolStripItem[] { this.toolStripMenuItem1, this.toolStripSeparator2, this.toolStripMenuItem2 });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new Size(0x99, 0x4c);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x98, 0x16);
            this.toolStripMenuItem1.Text = "Stop";
            this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(0x95, 6);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0x98, 0x16);
            this.toolStripMenuItem2.Text = "Close";
            this.toolStripMenuItem2.Click += new EventHandler(this.toolStripMenuItem2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1d8, 0x51);
            base.Controls.Add(this.toolStripContainer1);
            base.Name = "frmMain";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.Manual;
            this.Text = "MR Printer Status";
            base.FormClosing += new FormClosingEventHandler(this.frmMain_FormClosing);
            base.Load += new EventHandler(this.frmMain_Load);
            base.SizeChanged += new EventHandler(this.frmMain_SizeChanged);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.spc.EndInit();
            this.spc.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            base.Activate();
            if (base.WindowState == FormWindowState.Minimized)
            {
                base.WindowState = FormWindowState.Normal;
                base.ShowInTaskbar = true;
                this.notifyIcon1.Visible = false;
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if ("stop".Equals(this.toolStripMenuItem1.Text.ToLower()))
            {
                this.btnAllStop_Click(sender, e);
                this.toolStripMenuItem1.Text = "Start";
            }
            else
            {
                this.btnAllStart_Click(sender, e);
                this.toolStripMenuItem1.Text = "Stop";
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            base.Close();
        }
    }
}

